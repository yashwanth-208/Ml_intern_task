import pandas as pd

# Load the dataset
df = pd.read_csv(r"C:\New folder\MLtask\data\data.csv")

# Print first few rows
print(df.head())

# Print all column names
print(df.columns)
