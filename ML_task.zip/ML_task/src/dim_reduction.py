from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Load preprocessed data
df = pd.read_csv("data/processed_data.csv")
X = df.iloc[:, :-1].values

# PCA
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X)
print("Explained Variance:", pca.explained_variance_ratio_)

# t-SNE
tsne = TSNE(n_components=2, perplexity=30)
X_tsne = tsne.fit_transform(X)

# Plot PCA results
plt.figure(figsize=(6,4))
plt.scatter(X_pca[:,0], X_pca[:,1], alpha=0.6)
plt.title("PCA Visualization")
plt.show()

# Plot t-SNE results
plt.figure(figsize=(6,4))
plt.scatter(X_tsne[:,0], X_tsne[:,1], alpha=0.6, c=df.iloc[:, -1])
plt.title("t-SNE Visualization")
plt.show()
