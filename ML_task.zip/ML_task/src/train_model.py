import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# Load processed data
df = pd.read_csv(r"C:\New folder\MLtask\data\processed_data.csv")  # Use the preprocessed dataset

# Separate features and target
X = df.drop(columns=["hsi_id", "vomitoxin_ppb"])  # Drop ID and target
y = df["vomitoxin_ppb"]

# Split into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train a Random Forest model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Save the trained model
joblib.dump(model, "models/trained_model.pkl")

print("Model training complete. Model saved to 'models/trained_model.pkl'")
