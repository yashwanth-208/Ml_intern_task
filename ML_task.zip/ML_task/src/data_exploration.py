import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
df = pd.read_csv("data/data.csv")  # Replace with actual dataset name

# Check for missing values
print(df.isnull().sum())

# Describe the dataset
print(df.describe())

# Plot spectral reflectance distribution
plt.figure(figsize=(10,5))
plt.plot(df.iloc[:, :-1].T)  # Assuming last column is target
plt.title("Spectral Reflectance Across Wavelengths")
plt.xlabel("Wavelength Bands")
plt.ylabel("Reflectance")
plt.show()
