from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
import pandas as pd

# Load dataset
df = pd.read_csv(r"C:\New folder\MLtask\data\data.csv")

# Identify numeric and categorical columns
numeric_cols = df.select_dtypes(include=['number']).columns
categorical_cols = df.select_dtypes(include=['object']).columns

# Handle missing values separately
num_imputer = SimpleImputer(strategy="mean")
df[numeric_cols] = num_imputer.fit_transform(df[numeric_cols])  # Impute numerical data

cat_imputer = SimpleImputer(strategy="most_frequent")
df[categorical_cols] = cat_imputer.fit_transform(df[categorical_cols])  # Impute categorical data

# Normalize only numeric columns
scaler = StandardScaler()
df[numeric_cols] = scaler.fit_transform(df[numeric_cols])

# Save processed data
df.to_csv(r"C:\New folder\MLtask\data\processed_data.csv", index=False)

print("Preprocessing completed successfully.")
