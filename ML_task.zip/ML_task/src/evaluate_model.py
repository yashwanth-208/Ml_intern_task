import joblib
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import numpy as np

# Load the test dataset
test_data = pd.read_csv(r"C:\New folder\MLtask\data\data.csv")  # Using the correct dataset

# Print column names to verify
print("Columns in dataset:", test_data.columns)

# Set correct target column
target_column = "vomitoxin_ppb"

# Separate features (X) and target (y)
X_test = test_data.drop(columns=["hsi_id", target_column])  # Drop 'hsi_id' (identifier)
y_test = test_data[target_column]

# Load the trained model
model = joblib.load(r"C:\New folder\MLtask\models\trained_model.pkl")  # Ensure the model exists

# Make predictions
y_pred = model.predict(X_test)

# Evaluate model performance for regression
mae = mean_absolute_error(y_test, y_pred)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))  # Manual square root
r2 = r2_score(y_test, y_pred)

# Print evaluation metrics
print(f"Model Evaluation Metrics:\n"
      f"Mean Absolute Error (MAE): {mae:.4f}\n"
      f"Root Mean Squared Error (RMSE): {rmse:.4f}\n"
      f"R² Score: {r2:.4f}")

# Save the evaluation results
results = {
    "Mean Absolute Error": mae,
    "Root Mean Squared Error": rmse,
    "R² Score": r2
}

pd.DataFrame([results]).to_csv(r"C:\New folder\MLtask\result\evaluation_metrics.csv", index=False)
